#!/bin/bash

source Help.sh
source hwinfo.sh
source lspci.sh
source save.sh

echo -e "\n \n \tÂ \t Welcome to Project Scripting :D \n \n"


if [[ $# -eq 1 ]]; then
  case $1 in
    "-li" )
    hwinfo
      ;;
    "-lp" )
    Lspci
      ;;
    "-h" | "-help")
#!/bin/bash

source Help.sh
source hwinfo.sh
source lspci.sh
source save.sh

echo -e "\n \n \tÂ \t Welcome to Project Scripting :D \n \n"


if [[ $# -eq 1 ]]; then
  case $1 in
    "-li" )
    hwinfo
      ;;
    "-lp" )
    Lspci
      ;;
    "-h" | "-help")

    Help
      ;;
    "-s" | "--save")
    Save
        ;;
  esac

else

  while true ; do

    echo -e "\n \n"
    echo -e "\n 1 :  Connaître en détail les infos sur le matériel du pc. "
    echo -e "\n 2 : Afficher les dispositifs sur le bus PCI"
    echo -e "\n 3 : Afficher les carterstiques Hardware pertinentes.  "
    echo -e "\n 4 : Sauvegarder les informations. "
    echo -e "\n 5 : Quit. "
    echo -e "\n \n"
    read choix

    case $choix in


