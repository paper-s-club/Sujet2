function menu
{
   while (true)
   do
   echo "1-Pour afficher les caractéristiques hardware via <hwinfo> (-li)"
   echo "2-Pour afficher les caractéristiques hardware via <lspci> (-lp)"
   echo "3-sauvergarder les informations pertinentes et les afficher"
   echo "4-interface graphique"

   echo "donnez votre choix"
   read choix
   case $choix in
   
       1) hwinfo 
          echo "------------------------------------------------------------"
          ;;
     
       2) lspci
          echo "------------------------------------------------------------"
          ;;
      
       3) save
          echo "------------------------------------------------------------"
          echo "********************Done*************************"
          echo "------------------------------------------------------------"
          ;;

       4) graphic
          echo "------------------------------------------------------------"
          ;;

       *) break
          ;;
esac
done
} 


while getopts l:h:smg opt
do
      case "$opt" in
      l)   var="$OPTARG"
	   ;;

      h)   var="$OPTARG"
           ;;      

      s)   save
           echo "------------------------------------------------------------"
           echo "********************Done*************************"
           echo "------------------------------------------------------------"
           ;;
      
      g)   graphic
           ;;

      m)   menu
           ;;
      
      *)   echo "usage $0 {-li <hwinfo> | -lp <lspci> | -h <help> | -s <save> | -g <graphic> | -m <menu>}"
	  ;;

      esac
done

case $var in 

   i) hwinfo
      ;;
   
   p) lspci 
      ;;
   
   *)exit
esac
