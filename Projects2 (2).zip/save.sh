source hwinfo.sh
source lspci.sh
function save
{
   hwinfo > Hardware.txt
   lspci >> Hardware.txt
   cat Hardware.txt
}


