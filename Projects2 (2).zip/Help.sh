
function Help() {

  echo -e "\n -li : Connaître en détail les infos sur le matériel du pc"
  echo -e "\n -lp : Afficher les dispositifs sur le bus PCI "
  echo -e "\n -h -help : Afficher les carterstiques Hardware "
  echo -e "\n -s --save : Sauvegarder les informations "
}


