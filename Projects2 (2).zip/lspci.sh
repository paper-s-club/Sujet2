function Lspci() {
    lspci
}
