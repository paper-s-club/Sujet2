function  hwinfo() {
  man hwinfo --all --log hwinfo.txt
}

