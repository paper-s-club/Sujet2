#!/bin/bash
source Help.sh
source hwinfo.sh
source lspci.sh
source save.sh


	if ret=` zenity --entry --title="Projects2" --text="Veuillez Selectionner votre choix" "les infos sur le matériel du pc" "les dispositifs sur le bus PCI" "Carterstiques Hardware Pertinentes" "Help"`
		then
			titre=$ret
      case $titre in
        "les infos sur le matériel du pc" )
        hwinfo > /tmp/hwinfo.txt
        zenity --text-info \
       --title="les infos sur le matériel du pc" \
       --filename=/tmp/hwinfo.txt \

          ;;
        "les dispositifs sur le bus PCI" )
        Lspci  > /tmp/lspci.txt
        zenity --text-info \
       --title="les dispositifs sur le bus PCI" \
       --filename=/tmp/lspci.txt \
          ;;
        "Carterstiques Hardware Pertinentes")

        if [ -f "Hardware.txt" ]
        then
          zenity --question \
          --text="Voulez vous sauvegarder et afficher les infos pertinantes "
          case $? in
            0) echo "Yes"
            save
            zenity --info \
            --text="Sauvegarde reussi "
            save > /tmp/Hardware.txt
            zenity --text-info \
            --title="les infos pertinantes" \
            --filename=/tmp/Hardware.txt \
            ;;
            1) echo "No"
            zenity --info \
            --text="Sauvgarde annulee"
            ;;
          esac
       fi


          ;;
        "Help")
        texthelp=$(Help)
        zenity --info \
        --text="$texthelp"
            ;;
      esac

		else
			echo "Byeee :') "
			exit
	fi

 
